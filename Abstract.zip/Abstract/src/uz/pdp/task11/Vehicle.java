package uz.pdp.task11;

import java.util.StringJoiner;

public abstract class Vehicle {
    String model;
    String name;
    String vehicleType;
    int numberOfSeats;
    abstract void start();
    abstract void stop();

    public Vehicle() {
    }

    public Vehicle(String model, String name, String vehicleType, int numberOfSeats) {
        this.model = model;
        this.name = name;
        this.vehicleType = vehicleType;
        this.numberOfSeats = numberOfSeats;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Vehicle.class.getSimpleName() + "[", "]")
                .add("model='" + model + "'")
                .add("name='" + name + "'")
                .add("vehicleType='" + vehicleType + "'")
                .add("numberOfSeats=" + numberOfSeats)
                .toString();
    }
}

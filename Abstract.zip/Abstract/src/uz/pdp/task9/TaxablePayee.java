package uz.pdp.task9;

public interface TaxablePayee extends Payee{
}

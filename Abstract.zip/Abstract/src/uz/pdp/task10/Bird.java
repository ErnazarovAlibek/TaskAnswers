package uz.pdp.task10;

public class Bird implements Animal,Flight{
    @Override
    public void voice() {

    }

    @Override
    public void eat() {

    }

    @Override
    public void sleep() {

    }

    @Override
    public void walk() {

    }

    @Override
    public void fly() {

    }

    @Override
    public void land() {

    }

    public Bird() {
    }
}

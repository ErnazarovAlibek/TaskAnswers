package uz.pdp.task6;

public class Professor extends Person{
    double salary;
}

package uz.pdp.task8;

public class Spider extends Animal{
    void spider(){

    }
    @Override
    void eat() {

    }

    @Override
    void walk() {

    }
}

package uz.pdp.task11;

import java.util.StringJoiner;

public class Car2 extends WheeledVehicle{
    public Car2() {
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Car2.class.getSimpleName() + "[", "]")
                .add("numberOfWheels=" + numberOfWheels)
                .add("model='" + model + "'")
                .add("name='" + name + "'")
                .add("vehicleType='" + vehicleType + "'")
                .add("numberOfSeats=" + numberOfSeats)
                .toString();
    }
}

package uz.pdp.task3;

public abstract class BankAccount {
    String owner;
    Integer balance;
    abstract double deposit();
    abstract double withdraw();
}

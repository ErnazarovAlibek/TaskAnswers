package uz.pdp.task7;

public interface Fizz {
    void method();
}

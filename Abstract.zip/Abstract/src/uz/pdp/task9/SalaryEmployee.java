package uz.pdp.task9;

public class SalaryEmployee extends Employee{
}

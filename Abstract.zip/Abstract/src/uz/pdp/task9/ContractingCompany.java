package uz.pdp.task9;

public class ContractingCompany implements Payee{
}

package uz.pdp.task10;

public class Dog implements Animal{
    @Override
    public void voice() {

    }

    @Override
    public void eat() {

    }

    @Override
    public void sleep() {

    }

    @Override
    public void walk() {

    }

    public Dog() {
    }
}

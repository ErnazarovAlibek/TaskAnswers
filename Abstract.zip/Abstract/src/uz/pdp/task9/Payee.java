package uz.pdp.task9;

public interface Payee {

}

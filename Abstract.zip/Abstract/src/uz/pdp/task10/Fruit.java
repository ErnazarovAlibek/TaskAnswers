package uz.pdp.task10;

public class Fruit extends Product{
    public Fruit() {
    }
}

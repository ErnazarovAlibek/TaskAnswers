package uz.pdp.task10;

public class Product {
    double cost;
    String manufacturer;
}

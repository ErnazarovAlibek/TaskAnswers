package uz.pdp.task5;

import java.util.StringJoiner;

public abstract class Player {
    String sport;
    String team;
    String position;
    String last;
    String first;

    public Player() {
    }

    public Player(String sport, String team, String position, String last, String first) {
        this.sport = sport;
        this.team = team;
        this.position = position;
        this.last = last;
        this.first = first;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Player.class.getSimpleName() + "[", "]")
                .add("sport='" + sport + "'")
                .add("team='" + team + "'")
                .add("position='" + position + "'")
                .add("last='" + last + "'")
                .add("first='" + first + "'")
                .toString();
    }
}

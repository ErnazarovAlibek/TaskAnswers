package uz.pdp.task10;

public class Electronics extends Product{
    String model;
    int voltage;

}

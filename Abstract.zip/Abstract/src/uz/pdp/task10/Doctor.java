package uz.pdp.task10;

import java.util.StringJoiner;

public class Doctor extends Employee{
    @Override
    void toWork() {

    }

    public Doctor() {
    }

    public Doctor(String name, String surName, String citizenship, double salary) {
        super(name, surName, citizenship, salary);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Doctor.class.getSimpleName() + "[", "]")
                .add("salary=" + salary)
                .add("name='" + name + "'")
                .add("surName='" + surName + "'")
                .add("citizenship='" + citizenship + "'")
                .toString();
    }

}

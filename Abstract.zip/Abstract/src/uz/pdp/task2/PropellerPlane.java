package uz.pdp.task2;

public class PropellerPlane extends Aircraft{

    int propellers;
    @Override
    void start() {

    }

    @Override
    void stop() {

    }

    @Override
    void takeOf() {

    }

    @Override
    void land() {

    }
}

package uz.pdp.task10;

public interface Flight {
    void fly();
    void land();
}

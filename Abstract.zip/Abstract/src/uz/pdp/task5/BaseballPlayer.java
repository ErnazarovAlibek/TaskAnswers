package uz.pdp.task5;

import java.util.StringJoiner;

public class BaseballPlayer extends Player{
    int atBats;
    int hits;
    double battingAverage(){
        return hits/atBats;
    }

    public BaseballPlayer() {
    }

    public BaseballPlayer(String sport, String team, String position, String last, String first, int atBats, int hits) {
        super(sport, team, position, last, first);
        this.atBats = atBats;
        this.hits = hits;
    }

    public int getAtBats() {
        return atBats;
    }

    public void setAtBats(int atBats) {
        this.atBats = atBats;
    }

    public int getHits() {
        return hits;
    }

    public void setHits(int hits) {
        this.hits = hits;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", BaseballPlayer.class.getSimpleName() + "[", "]")
                .add("sport='" + sport + "'")
                .add("team='" + team + "'")
                .add("position='" + position + "'")
                .add("last='" + last + "'")
                .add("first='" + first + "'")
                .add("atBats=" + atBats)
                .add("hits=" + hits)
                .toString();
    }
}

package uz.pdp.task4;

public interface Office {
    void setNumber();
    void getNumber();
    void setOccupant();
    void getOccupant();
}

package uz.pdp.task3;

public class CheckAccount extends BankAccount{
    @Override
    double deposit() {
        return 0;
    }

    @Override
    double withdraw() {
        return 0;
    }
    public void check(){

    }
}

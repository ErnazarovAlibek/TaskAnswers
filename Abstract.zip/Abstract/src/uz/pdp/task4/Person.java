package uz.pdp.task4;

public class Person implements Employee{
    String name;
    String address;
    String hairColor;
    String eyeColor;
    @Override
    public void hire() {

    }

    @Override
    public void fire() {

    }

    public void setName(String name) {
        this.name = name;
    }

    public void newAddress(String name) {}
}

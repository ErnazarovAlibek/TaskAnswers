package uz.pdp.task10;

import java.util.StringJoiner;

public class Person implements Creatures{
    String name;
    String surName;
    String citizenship;

    @Override
    public void eat() {

    }

    @Override
    public void sleep() {

    }

    @Override
    public void walk() {

    }

    public Person() {
    }

    public Person(String name, String surName, String citizenship) {
        this.name = name;
        this.surName = surName;
        this.citizenship = citizenship;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurName() {
        return surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    public String getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Person.class.getSimpleName() + "[", "]")
                .add("name='" + name + "'")
                .add("surName='" + surName + "'")
                .add("citizenship='" + citizenship + "'")
                .toString();
    }
}

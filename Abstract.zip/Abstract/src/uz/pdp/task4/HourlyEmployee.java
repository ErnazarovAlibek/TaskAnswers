package uz.pdp.task4;

public class HourlyEmployee extends Person{
    int hourlyRate;
    int jobId;

    public void setRate(int hourlyRate) {
        this.hourlyRate = hourlyRate;
    }
}

package uz.pdp.task1;

public abstract class Shape {
    String color;
    abstract double area();
    void getColor(String color){
        System.out.println("color");
    }
}

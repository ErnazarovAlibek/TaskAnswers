package uz.pdp.task10;

public interface Animal extends Creatures{
    int numberOfEyes = 2;
    void voice();

}

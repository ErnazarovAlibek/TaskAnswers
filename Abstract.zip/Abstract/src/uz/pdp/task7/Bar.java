package uz.pdp.task7;

public class Bar {
    String field;
    String field1;
    String field2;
}

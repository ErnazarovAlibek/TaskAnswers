package uz.pdp.task6;

public class Person {
    String firstName;
    String lastName;

}

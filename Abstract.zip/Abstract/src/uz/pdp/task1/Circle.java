package uz.pdp.task1;

public class Circle extends Shape{
    double radius;

    @Override
    double area() {
        return Math.PI*radius*radius;
    }
}

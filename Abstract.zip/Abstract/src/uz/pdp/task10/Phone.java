package uz.pdp.task10;

public class Phone extends Electronics implements Technique{
    @Override
    public boolean onOf() {
        return false;
    }

    @Override
    public void repair() {

    }

    public Phone() {
    }
}

package uz.pdp.task10;

import java.util.StringJoiner;

public abstract class Employee extends Person{
    abstract void toWork();
    double salary;

    public Employee() {
    }

    public Employee(String name, String surName, String citizenship, double salary) {
        super(name, surName, citizenship);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Employee.class.getSimpleName() + "[", "]")
                .add("salary=" + salary)
                .add("name='" + name + "'")
                .add("surName='" + surName + "'")
                .add("citizenship='" + citizenship + "'")
                .toString();
    }
}

package uz.pdp.task2;

public abstract class Aircraft {
    String color;
    Object engine;
    abstract void start();
    abstract void stop();
    abstract void takeOf();
    abstract void land();
}

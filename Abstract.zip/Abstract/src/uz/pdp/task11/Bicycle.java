package uz.pdp.task11;

import java.util.StringJoiner;

public class Bicycle extends WheeledVehicle{
    public Bicycle() {
    }

    public Bicycle(String model, String name, String vehicleType, int numberOfSeats, int numberOfWheels) {
        super(model, name, vehicleType, numberOfSeats, numberOfWheels);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Bicycle.class.getSimpleName() + "[", "]")
                .add("numberOfWheels=" + numberOfWheels)
                .add("model='" + model + "'")
                .add("name='" + name + "'")
                .add("vehicleType='" + vehicleType + "'")
                .add("numberOfSeats=" + numberOfSeats)
                .toString();
    }
}

package uz.pdp.task10;

import java.util.StringJoiner;

public class Student extends Person{
    double scholarship;
    String education;

    public Student() {
    }

    public Student(String name, String surName, String citizenship, double scholarship, String education) {
        super(name, surName, citizenship);
        this.scholarship = scholarship;
        this.education = education;
    }

    public double getScholarship() {
        return scholarship;
    }

    public void setScholarship(double scholarship) {
        this.scholarship = scholarship;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Student.class.getSimpleName() + "[", "]")
                .add("scholarship=" + scholarship)
                .add("education='" + education + "'")
                .add("name='" + name + "'")
                .add("surName='" + surName + "'")
                .add("citizenship='" + citizenship + "'")
                .toString();
    }
}

package uz.pdp.task5;

import java.util.StringJoiner;

public class SoccerPlayer extends Player{
    int minutes;
    int goals;
    double goalsPerGames(){
        return goals/(minutes/90);
    }

    public SoccerPlayer() {
    }

    public SoccerPlayer(String sport, String team, String position, String last, String first, int minutes, int goals) {
        super(sport, team, position, last, first);
        this.minutes = minutes;
        this.goals = goals;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    public int getGoals() {
        return goals;
    }

    public void setGoals(int goals) {
        this.goals = goals;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", SoccerPlayer.class.getSimpleName() + "[", "]")
                .add("sport='" + sport + "'")
                .add("team='" + team + "'")
                .add("position='" + position + "'")
                .add("last='" + last + "'")
                .add("first='" + first + "'")
                .add("minutes=" + minutes)
                .add("goals=" + goals)
                .toString();
    }
}

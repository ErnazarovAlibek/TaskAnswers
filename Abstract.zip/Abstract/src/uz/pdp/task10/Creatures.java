package uz.pdp.task10;

public interface Creatures {
    void eat();
    void sleep();
    void walk();
}

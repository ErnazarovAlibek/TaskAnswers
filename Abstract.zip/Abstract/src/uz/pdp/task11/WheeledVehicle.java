package uz.pdp.task11;

import java.util.StringJoiner;

public class WheeledVehicle extends Vehicle{
    int numberOfWheels;
    @Override
    void start() {

    }

    @Override
    void stop() {

    }

    public WheeledVehicle() {
    }

    public WheeledVehicle(String model, String name, String vehicleType, int numberOfSeats, int numberOfWheels) {
        super(model, name, vehicleType, numberOfSeats);
        this.numberOfWheels = numberOfWheels;
    }

    public int getNumberOfWheels() {
        return numberOfWheels;
    }

    public void setNumberOfWheels(int numberOfWheels) {
        this.numberOfWheels = numberOfWheels;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", WheeledVehicle.class.getSimpleName() + "[", "]")
                .add("numberOfWheels=" + numberOfWheels)
                .add("model='" + model + "'")
                .add("name='" + name + "'")
                .add("vehicleType='" + vehicleType + "'")
                .add("numberOfSeats=" + numberOfSeats)
                .toString();
    }
}

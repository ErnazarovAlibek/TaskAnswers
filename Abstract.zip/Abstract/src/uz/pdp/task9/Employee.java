package uz.pdp.task9;

public abstract class Employee implements TaxablePayee {
}

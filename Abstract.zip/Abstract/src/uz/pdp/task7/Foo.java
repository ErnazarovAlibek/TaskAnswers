package uz.pdp.task7;

public class Foo extends Bar implements Fizz{
    @Override
    public void method() {

    }
}

package uz.pdp.task8;

public abstract class Animal {
    int legs;
    abstract void eat();
    abstract void walk();
}

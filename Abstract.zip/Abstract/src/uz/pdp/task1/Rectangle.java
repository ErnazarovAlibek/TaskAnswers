package uz.pdp.task1;

public class Rectangle extends Shape{
    double length;
    double width;

    @Override
    double area() {
        return length*width;
    }
}

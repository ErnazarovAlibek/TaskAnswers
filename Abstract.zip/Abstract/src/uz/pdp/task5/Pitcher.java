package uz.pdp.task5;

public class Pitcher extends BaseballPlayer{
    double innings;
    int earnedRuns;
    double earnedRunsAverage(){
       return earnedRuns/innings;
    }

    public Pitcher() {
    }

    public Pitcher(String sport, String team, String position, String last, String first, int atBats, int hits, double innings, int earnedRuns) {
        super(sport, team, position, last, first, atBats, hits);
        this.innings = innings;
        this.earnedRuns = earnedRuns;
    }
}

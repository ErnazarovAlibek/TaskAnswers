package uz.pdp.task10;

import java.util.StringJoiner;

public class Programmer extends Employee {
    @Override
    void toWork() {

    }

    public Programmer() {
    }

    public Programmer(String name, String surName, String citizenship, double salary) {
        super(name, surName, citizenship, salary);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Programmer.class.getSimpleName() + "[", "]")
                .add("salary=" + salary)
                .add("name='" + name + "'")
                .add("surName='" + surName + "'")
                .add("citizenship='" + citizenship + "'")
                .toString();
    }
}

package uz.pdp.task10;

public interface Remote {
    void changeChannel();
    void changeSound();
    void settings();
}

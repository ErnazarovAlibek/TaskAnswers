package uz.pdp.task2;

public class PassengerPlane extends Aircraft {
    int passengers;
    @Override
    void start() {

    }

    @Override
    void stop() {

    }

    @Override
    void takeOf() {

    }

    @Override
    void land() {

    }
}

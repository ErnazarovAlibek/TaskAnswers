package uz.pdp.task5;

import java.util.StringJoiner;

public class Goalie extends  SoccerPlayer{
    int goalsAllowed;
    double averageGoalsAllowed;

    public Goalie() {
    }

    public Goalie(String sport, String team, String position, String last, String first, int minutes, int goals, int goalsAllowed, double averageGoalsAllowed) {
        super(sport, team, position, last, first, minutes, goals);
        this.goalsAllowed = goalsAllowed;
        this.averageGoalsAllowed = averageGoalsAllowed;
    }

    public int getGoalsAllowed() {
        return goalsAllowed;
    }

    public void setGoalsAllowed(int goalsAllowed) {
        this.goalsAllowed = goalsAllowed;
    }

    public double getAverageGoalsAllowed() {
        return averageGoalsAllowed;
    }

    public void setAverageGoalsAllowed(double averageGoalsAllowed) {
        this.averageGoalsAllowed = averageGoalsAllowed;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Goalie.class.getSimpleName() + "[", "]")
                .add("goalsAllowed=" + goalsAllowed)
                .add("averageGoalsAllowed=" + averageGoalsAllowed)
                .add("minutes=" + minutes)
                .add("goals=" + goals)
                .add("sport='" + sport + "'")
                .add("team='" + team + "'")
                .add("position='" + position + "'")
                .add("last='" + last + "'")
                .add("first='" + first + "'")
                .toString();
    }
}

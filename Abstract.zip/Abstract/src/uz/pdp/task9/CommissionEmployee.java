package uz.pdp.task9;

public class CommissionEmployee extends Employee {
}

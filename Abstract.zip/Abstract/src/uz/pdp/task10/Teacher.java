package uz.pdp.task10;

import java.util.StringJoiner;

public class Teacher extends Employee{
    @Override
    void toWork() {

    }

    public Teacher() {
    }

    public Teacher(String name, String surName, String citizenship, double salary) {
        super(name, surName, citizenship, salary);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Teacher.class.getSimpleName() + "[", "]")
                .add("salary=" + salary)
                .add("name='" + name + "'")
                .add("surName='" + surName + "'")
                .add("citizenship='" + citizenship + "'")
                .toString();
    }
}

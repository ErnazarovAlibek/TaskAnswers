package uz.pdp.task4;

public class SalariedEmployee extends Person implements Office{
    double weeklyPay;

    @Override
    public void setNumber() {

    }

    @Override
    public void getNumber() {

    }

    @Override
    public void setOccupant() {

    }

    @Override
    public void getOccupant() {

    }

    public void setWage(){

    }
    public void moveOffice(){

    }
}

package uz.pdp.task8;

public interface Pet {
    String getName();
    String setName(String name);
    String play();
}

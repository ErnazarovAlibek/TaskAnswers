package uz.pdp.task10;

public class Auto implements Technique{
    @Override
    public boolean onOf() {
        return false;
    }

    @Override
    public void repair() {

    }

    public Auto() {
    }

}

package uz.pdp.task12;

import java.util.Observer;

public interface Subject {
    void registerObserver(Observer o);
    void unRegisterObserver(Observer o);
    void notifyObserver();
}

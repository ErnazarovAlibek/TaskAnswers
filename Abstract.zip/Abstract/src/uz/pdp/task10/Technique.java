package uz.pdp.task10;

public interface Technique {
    boolean onOf();
    void repair();

}

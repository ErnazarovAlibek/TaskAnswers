package uz.pdp.task10;

public class Plane implements Technique, Flight{
    @Override
    public void fly() {

    }

    @Override
    public void land() {

    }

    @Override
    public boolean onOf() {
        return false;
    }

    @Override
    public void repair() {

    }

    public Plane() {
    }
}

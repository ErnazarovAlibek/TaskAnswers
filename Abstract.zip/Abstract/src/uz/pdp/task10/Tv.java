package uz.pdp.task10;

import uz.pdp.task9.TaxablePayee;

import java.util.StringJoiner;

public class Tv extends Electronics implements Technique,Remote {
    @Override
    public void changeChannel() {

    }

    @Override
    public void changeSound() {

    }

    @Override
    public void settings() {

    }

    @Override
    public boolean onOf() {
        return false;
    }

    @Override
    public void repair() {

    }

    public Tv() {
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Tv.class.getSimpleName() + "[", "]")
                .add("model='" + model + "'")
                .add("voltage=" + voltage)
                .add("cost=" + cost)
                .add("manufacturer='" + manufacturer + "'")
                .toString();
    }
}

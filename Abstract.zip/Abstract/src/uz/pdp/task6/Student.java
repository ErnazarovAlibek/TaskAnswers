package uz.pdp.task6;

public class Student extends Person{
    String major;

}

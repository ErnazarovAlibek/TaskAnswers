package uz.pdp.task4;

public interface Employee {
    void hire();
    void fire();
}

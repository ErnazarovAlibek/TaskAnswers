package uz.pdp.task8;

public class Cat extends Animal implements Pet{
    void cat(String name){

    }
    void cat(){

    }


    @Override
    void eat() {

    }

    @Override
    void walk() {

    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String setName(String name) {
        return null;
    }

    @Override
    public String play() {
        return null;
    }
}
